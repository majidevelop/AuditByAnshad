<?php 
//echo "<script> window.location='login';</script>";
//header("Location: login");
//echo "hi";
error_reporting(E_ALL);
ini_set('display_errors', 1);

include('blade.php');
?>